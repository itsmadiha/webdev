var builder = WebApplication.CreateBuilder(args);
//add services for MVC
builder.Services.AddControllersWithViews();
var app = builder.Build();
//configure pipline for Dev. Env Request
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
  }  
//Adding Middlewears
app.UseStaticFiles();
app.UseRouting();
app.MapControllerRoute(
    name: "deafult",
    pattern:"{Controller=Home}/{action=index}/{id?}"
    );


app.Run();
